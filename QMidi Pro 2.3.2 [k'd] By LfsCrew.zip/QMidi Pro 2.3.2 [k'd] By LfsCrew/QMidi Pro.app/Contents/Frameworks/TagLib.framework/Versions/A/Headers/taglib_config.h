/* taglib/taglib_config.h.  Generated from taglib_config.h.in by configure.  */
/* With ASF support */
/* #undef TAGLIB_WITH_ASF */

/* With MP4 support */
/* #undef TAGLIB_WITH_MP4 */
